import React from "react";
import { Column, Table, SortDirection, AutoSizer } from "react-virtualized";
import "./index.css";
import "react-virtualized/styles.css";
import _ from "lodash";
import { Container, Row, Col } from 'reactstrap';


let list = [];
for (let i = 0; i < 10; i++) {
  list.push({ name: `${i} A`, description: `${i} B` });
}

class Home extends React.Component {
  constructor(props) {
    super(props);

    const sortBy = "name";
    const sortDirection = SortDirection.ASC;
    const sortedList = this._sortList({ sortBy, sortDirection });

    this.state = {
      sortBy,
      sortDirection,
      sortedList
    };
  }

  render() {
    return (
      <Container>
        <Row>
          <Col sm="12" md={{ size: 6, offset: 3 }}>
            <div style={{ height: 400 }}>

              <AutoSizer>
                {({ height, width }) => (
                  <Table
                    width={width}
                    height={height}
                    headerHeight={20}
                    rowHeight={30}
                    sort={this._sort}
                    sortBy={this.state.sortBy}
                    sortDirection={this.state.sortDirection}
                    rowCount={this.state.sortedList.length}
                    rowGetter={({ index }) => this.state.sortedList[index]}
                  >
                    <Column label="Name" dataKey="name" width={200} />
                    <Column width={300} label="Description" dataKey="description" />
                  </Table>
                )}
              </AutoSizer>
            </div>
          </Col>
        </Row>
        <Row id="d2"> </Row>
      </Container>
    );
  }

  _sortList = ({ sortBy, sortDirection }) => {
    let newList = _.sortBy(list, [sortBy]);
    if (sortDirection === SortDirection.DESC) {
      newList.reverse();
    }
    return newList;
  };

  _sort = ({ sortBy, sortDirection }) => {
    const sortedList = this._sortList({ sortBy, sortDirection });
    this.setState({ sortBy, sortDirection, sortedList });
  };
}
export default Home;