window.onload = () => {
    document.getElementById("d2").innerHTML = '<iframe name="d1f1" scrolling="no" src="https://angularjs.org/" frameborder="0" allowfullScreen ></iframe>';

    var divStyle = document.createElement('style');
    divStyle.type = 'text/css';
    divStyle.innerHTML = '.iframe-container {overflow: hidden;padding-top: 56.25%; position: relative;}';
    document.getElementsByTagName('head')[0].appendChild(divStyle);
    document.getElementById('d2').className = 'iframe-container';

    var iFramestyle = document.createElement('style');
    iFramestyle.type = 'text/css';
    iFramestyle.innerHTML = '.iframe-container iframe {border: 0;height: 100%;left: 0; position: absolute; top: 0;  width: 100%;}';
    document.getElementsByTagName('head')[0].appendChild(iFramestyle);
    document.getElementsByName('d1f1').className = 'iframe-container iframe';
};
