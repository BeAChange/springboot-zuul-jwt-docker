import React from 'react';

class Hello extends React.Component {  
      
    constructor(){  
        super();  
        this.state = {  
            message: "(from state)!"  
        };  
        this.updateMessage = this.updateMessage.bind(this);  
    }

    updateMessage() {  
        this.setState({  
            message: "(to state)!"  
        });  
    }

    render() {  
         return (  
           <div>  
             <h1>Hello {this.state.message}!</h1>  
             <button onClick={this.updateMessage} value="Click me!"/>
           </div>     
        )  
    }  
}

export default Hello;